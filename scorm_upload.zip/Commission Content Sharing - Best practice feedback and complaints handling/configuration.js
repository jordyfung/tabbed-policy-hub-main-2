// web location of the content host's dispatch files (dispatch.client.loader.js, DispatchHost.html, etc.)
DispatchRoot = 'https://learning.prod-gov1-ap-southeast-2.dispatch.acornplms.com/RusticiEngine/dispatch/';

// version of dispatch
DispatchVersion = '1';

// web location of the content host's launch process which ultimately leads to the content host Engine launch URL
ContentURL = 'https://learning.prod-gov1-ap-southeast-2.dispatch.acornplms.com/RusticiEngine/dispatch/DispatchRequest.jsp?methodName=Launch&tenant=learning.agedcarequality.gov.au-1&dispatchid=3-83&launchsecret=-6_W3mh_aYOsMs9d1KVN2UJuv-VZ&learnerid=LEARNER_ID&fname=LEARNER_FNAME&lname=LEARNER_LNAME&pipeurl=PIPE_URL&redirecturl=REDIRECT_URL_REGISTRATION_ARGUMENT';

// optional web location that provides pre-launch configuration object
PreLaunchConfigurationURL = 'https://dispatch-obscurify-json.s3.ap-southeast-2.amazonaws.com/dispatchLaunchConfig.json';
