// SCORM 1.2 API Implementation
// This is a minimal SCORM driver for testing

var API = null;
var findAPITries = 0;

function findAPI(win) {
    while ((win.API == null) && (win.parent != null) && (win.parent != win)) {
        findAPITries++;
        if (findAPITries > 7) {
            findAPITries = 0;
            return null;
        }
        win = win.parent;
    }
    return win.API;
}

function getAPI() {
    if (API == null) {
        API = findAPI(window);
    }
    return API;
}

// SCORM 1.2 API Functions
function LMSInitialize(parameter) {
    var api = getAPI();
    if (api != null) {
        return api.LMSInitialize(parameter);
    }
    return "false";
}

function LMSFinish(parameter) {
    var api = getAPI();
    if (api != null) {
        return api.LMSFinish(parameter);
    }
    return "false";
}

function LMSGetValue(element) {
    var api = getAPI();
    if (api != null) {
        return api.LMSGetValue(element);
    }
    return "";
}

function LMSSetValue(element, value) {
    var api = getAPI();
    if (api != null) {
        return api.LMSSetValue(element, value);
    }
    return "false";
}

function LMSCommit(parameter) {
    var api = getAPI();
    if (api != null) {
        return api.LMSCommit(parameter);
    }
    return "false";
}

function LMSGetLastError() {
    var api = getAPI();
    if (api != null) {
        return api.LMSGetLastError();
    }
    return "0";
}

function LMSGetErrorString(errorCode) {
    var api = getAPI();
    if (api != null) {
        return api.LMSGetErrorString(errorCode);
    }
    return "";
}

function LMSGetDiagnostic(errorCode) {
    var api = getAPI();
    if (api != null) {
        return api.LMSGetDiagnostic(errorCode);
    }
    return "";
}

// Initialize API when script loads
window.API = {
    LMSInitialize: LMSInitialize,
    LMSFinish: LMSFinish,
    LMSGetValue: LMSGetValue,
    LMSSetValue: LMSSetValue,
    LMSCommit: LMSCommit,
    LMSGetLastError: LMSGetLastError,
    LMSGetErrorString: LMSGetErrorString,
    LMSGetDiagnostic: LMSGetDiagnostic
};
