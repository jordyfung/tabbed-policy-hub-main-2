// Dispatch Client Loader
// Minimal implementation for SCORM content loading

var strLMSStandard = "SCORM";
var DebugMode = false;

function Start() {
    console.log("Dispatch Start called");
    // Initialize the SCORM content
    if (typeof LMSInitialize !== 'undefined') {
        var result = LMSInitialize('');
        console.log("LMSInitialize result:", result);
    }
}

function LoadContent() {
    console.log("LoadContent called");
    // Load the SCORM content directly into the page
    fetch('blank.html')
        .then(response => response.text())
        .then(html => {
            // Replace the body content with the SCORM content
            document.body.innerHTML = html;
            console.log("SCORM content loaded successfully");
        })
        .catch(error => {
            console.error("Error loading SCORM content:", error);
            // Fallback: show a simple message
            document.body.innerHTML = '<div style="padding: 20px; font-family: Arial, sans-serif;"><h1>SCORM Course</h1><p>Course content is loading...</p></div>';
        });
}

function Unload() {
    console.log("Dispatch Unload called");
    // Clean up when leaving the content
    if (typeof LMSFinish !== 'undefined') {
        var result = LMSFinish('');
        console.log("LMSFinish result:", result);
    }
}

function ShowDebugWindow() {
    console.log("Debug window would be shown here");
}

function WriteToDebug(message) {
    console.log("Debug:", message);
}

// Make functions globally available
window.Start = Start;
window.LoadContent = LoadContent;
window.Unload = Unload;
window.ShowDebugWindow = ShowDebugWindow;
window.WriteToDebug = WriteToDebug;
