// Dispatch Client Loader
// Minimal implementation for SCORM content loading

var strLMSStandard = "SCORM";
var DebugMode = false;

function Start() {
    console.log("Dispatch Start called");
    // Initialize the SCORM content
    if (typeof LMSInitialize !== 'undefined') {
        var result = LMSInitialize('');
        console.log("LMSInitialize result:", result);
    }
}

function LoadContent() {
    console.log("LoadContent called");
    // This would normally load the actual SCORM content
    // For now, we'll just show a simple message
    var contentFrame = document.getElementById('dispatch_content_frame');
    if (contentFrame) {
        contentFrame.style.display = 'block';
        contentFrame.src = 'blank.html';
    }
}

function Unload() {
    console.log("Dispatch Unload called");
    // Clean up when leaving the content
    if (typeof LMSFinish !== 'undefined') {
        var result = LMSFinish('');
        console.log("LMSFinish result:", result);
    }
}

function ShowDebugWindow() {
    console.log("Debug window would be shown here");
}

function WriteToDebug(message) {
    console.log("Debug:", message);
}

// Make functions globally available
window.Start = Start;
window.LoadContent = LoadContent;
window.Unload = Unload;
window.ShowDebugWindow = ShowDebugWindow;
window.WriteToDebug = WriteToDebug;
